import React, { useState, useEffect } from 'react';
import { gameState } from './game/gameState';
import { TradingSystem } from './game/systems/trading';
import { gameData } from './game/data/gameData';
import PlayerStats from './components/PlayerStats';
import InventoryModal from './components/InventoryModal';
import Market from './components/Market';
import './App.css';

function App() {
  const [isInventoryOpen, setInventoryOpen] = useState(false);
  const [, setRerender] = useState(0); // Used to force re-render

  useEffect(() => {
    // Always try to load from localStorage on mount
    if (typeof gameState.load === 'function') {
      gameState.load();
    }

    // Helper: check if cityPrices is missing, empty, or any city has an empty price list
    const isCityPricesInvalid =
      !gameState.cityPrices ||
      Object.keys(gameState.cityPrices).length === 0 ||
      Object.values(gameState.cityPrices).some(
        (prices) => !prices || Object.keys(prices).length === 0
      );

    if (isCityPricesInvalid) {
      const tradingSystem = new TradingSystem(gameState, null, gameData);
      tradingSystem.generateAllCityPrices();
      if (typeof gameState.save === 'function') {
        gameState.save();
      }
    }

    const rerender = () => setRerender(x => x + 1);
    gameState.on('stateChange', rerender);
    return () => {
      gameState.off('stateChange', rerender);
    };
  }, []);

  return (
    <div>
      <h1>Slang & Bang (React Port)</h1>
      <PlayerStats
        playerName={gameState.data.playerName}
        cash={gameState.data.cash}
        currentCity={gameState.data.currentCity}
        day={gameState.data.day}
        heatLevel={gameState.data.heatLevel}
      />
      <button onClick={() => setInventoryOpen(true)}>Show Inventory</button>
      <InventoryModal
        inventory={gameState.data.inventory}
        isOpen={isInventoryOpen}
        onClose={() => setInventoryOpen(false)}
      />
      <Market cityPrices={gameState.cityPrices[gameState.data.currentCity] || {}} />
    </div>
  );
}

export default App;
