import React from 'react';

type MarketProps = {
  cityPrices: { [drug: string]: number };
};

const Market: React.FC<MarketProps> = ({ cityPrices }) => (
  <div>
    <h2>Market Prices</h2>
    <table>
      <thead>
        <tr>
          <th>Drug</th>
          <th>Price ($)</th>
        </tr>
      </thead>
      <tbody>
        {Object.entries(cityPrices).map(([drug, price]) => (
          <tr key={drug}>
            <td>{drug}</td>
            <td>{price}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

export default Market;